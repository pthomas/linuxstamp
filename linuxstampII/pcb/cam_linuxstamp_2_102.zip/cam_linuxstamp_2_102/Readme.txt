Top copper 		-> *.cmp
Layer 2 copper		-> *.l02
Layer 3 copper		-> *.l03
Layer 14 copper		-> *.l15
Layer 15 copper		-> *.l16
Bottom copper		-> *.sol
Top silk screen 	-> *.plc
Bottom silk screen	-> *.pls
Top solder mask 	-> *.stc
Bottom solder mask	-> *.sts
Dimension		-> *.dmm
Excellon drill		-> *.drd
Top cream		-> *.tcr
Bottom cream		-> *.bcr
XYRS file		-> *.mnt