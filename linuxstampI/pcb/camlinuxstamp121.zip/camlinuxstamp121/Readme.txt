Top copper 		-> *.cmp
Bottom copper		-> *.sol
Top silk screen 	-> *.plc
Bottom silk screen	-> *.pls
Top solder mask 	-> *.stc
Bottom solder mask	-> *.sts
Dimension		-> *.dmm
Excellon drill		-> *.drd
Top cream		-> *.tcr
Bottom cream		-> *.bcr
XYRS file		-> *.mnt